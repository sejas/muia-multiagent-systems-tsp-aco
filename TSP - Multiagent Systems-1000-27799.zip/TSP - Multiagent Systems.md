# Multiagent systems - TSP Problem


```python
import tsplib95
from random import randrange, random, shuffle
from bisect import bisect
import pandas as pd
import matplotlib.pyplot as plt
# import pixiedust
import numpy as np
```


```python
#!pip install ipython-autotime
%load_ext autotime
```

## Load TSP Problem


```python
# Data Source : http://www.math.uwaterloo.ca/tsp/world/countries.html
#TSP_FILE = 'uy734.tsp' # 🇺🇾 Uruguay
TSP_FILE = 'wi29.tsp' # 🇪🇭 Western Sahara
#TSP_FILE = 'ca4663.tsp' # 🇨🇦 Canada
```

    time: 524 µs



```python
# LOAD TSP FILE
PROBLEM = tsplib95.load(TSP_FILE)
print(type(PROBLEM))
```

    <class 'tsplib95.models.StandardProblem'>
    time: 3.04 ms



```python
PROBLEM.type
```




    'TSP'



    time: 3.19 ms



```python
N = len(list(PROBLEM.get_nodes())) # N is total cities
print("%s Cities"%N)
```

    29 Cities
    time: 853 µs



```python
# Example city coordinates
PROBLEM.node_coords[3]
```




    [21300.0, 13016.6667]



    time: 1.84 ms



```python
# Distance between first and last cities
edge = {'start':1,'end':N}
PROBLEM.get_weight(**edge)
```




    7799



    time: 2.4 ms


## Basic Ant


```python
class Ant:
    tour = None
    tsp = PROBLEM
    _tour_weight_cache = {'n_cities':0, 'weight': 0} # code optimization
    
    def __init__(self, city_i=0):
        self.tour = []
        if city_i>0:
            self.visit(city_i)
    
    @property
    def current_city(self):
        return self.tour[-1]

    @property
    def tour_weight(self):
        if len(self.tour) != self._tour_weight_cache['n_cities']:
            self._tour_weight_cache['weight'] = self.tsp.trace_tours([self.tour])[0]
        return self._tour_weight_cache['weight']
    
    def visit(self, i:int):
        if i in self.tour and i != self.tour[0]:
            raise Exception("The city i: %s is already visited. Imposible to visit again"%i)
        if i < 1 or i > N:
            raise Exception("The city i (%s) is out of range: -> [1, %s]"%(i, N))
        self.tour.append(i)
    
    def distance_to(self, city_j:int):
        return self.tsp.get_weight(self.current_city, city_j)
    
    def _not_visited_cities(self):
        return [i for i in range(1,N+1) if i not in self.tour]
    
    def _raw_probability(self, city_j:int, pheromones_matrix):
        ## ASSUMPTION: We consider the edge has two ways. Phromones to go and to go back. In other words. I->J != J->I
        # careful, we must substract one from the cities index
        return (pheromones_matrix[self.current_city-1][city_j-1]**ALPHA) * ((1/self.distance_to(city_j))**BETA)
    
    def normalized_probabilities(self, pheromones_matrix):
        """ Returns a tuple
            First element: List of neighbors, cities not visited
            Second element: List of probabilities calculated with the formular of tau_ij^A* h_ij^B
        """
        neighbors = self._not_visited_cities()
        neighbors_pheromone_list = [self._raw_probability(neighbor_j, pheromones_matrix) for neighbor_j in neighbors]
        total = sum(neighbors_pheromone_list)
        normalized_probabilities = [pheromone_ij/total for pheromone_ij in neighbors_pheromone_list]
        #print(normalized_probabilities)
        return neighbors, normalized_probabilities
        
    def pick_next_city(self, cities, probabilities):
        roulette_x = random()
        idx = 0
        roulette_sum = 0
        for p in probabilities:
            roulette_sum += p
            if roulette_sum >= roulette_x  :
                return cities[idx]
            idx += 1
    
    def finished_tour(self):
        return len(self.tour) == N

    def plot_hot_map(self):
        df = pd.DataFrame([[0 for j in N] for i in N])
        for posi_i in range(1, len(ant.tour)):
            i = ant.tour[posi_i-1]-1
            j = ant.tour[posi_i]-1
            pheromones_to_add[i][j] += tau_delta
            
        plt.imshow(df, cmap='hot', interpolation='nearest')
        plt.show()
```

    time: 5.39 ms



```python
a = Ant(1)
print(a.tour)
a.visit(29)
print(a.tour)
print("Total weight of this ant tour is: %s"%a.tour_weight)
```

    [1]
    [1, 29]
    Total weight of this ant tour is: 15598
    time: 1.08 ms



```python
def plot_pheromones(df, step, show=True, title=''):
    print(title)
    plt.imshow(df, cmap='hot', interpolation='nearest')
    plt.savefig("pheromones-%03d.png"%step)
    plt.show()
    #plt.imsave("pheromones-%03d.png"%step, df, cmap='hot')
```

    time: 860 µs


## BASE LINE


```python
# Solution joining all the cities in sequence
ant = Ant(1)
for i in range(2,N+1):
    ant.visit(i)
print(ant.tour)
print(ant.tour_weight)
```

    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29]
    52284
    time: 1.34 ms



```python
# Random Solution
ant = Ant(1)
random_cities = list(range(2,N+1))
shuffle(random_cities)
for i in random_cities:
    ant.visit(i)
print(ant.tour)
print(ant.tour_weight)
```

    [1, 18, 7, 4, 2, 24, 14, 19, 29, 15, 28, 9, 27, 11, 22, 12, 3, 6, 23, 17, 16, 25, 20, 8, 21, 10, 5, 13, 26]
    109358
    time: 1.48 ms



```python
# Solution using the heuristic
ant = Ant(1)
while not ant.finished_tour():
    neighbors = ant._not_visited_cities()
    distances = []
    for city_j in range(1, len(neighbors)+1):
        distances.append(ant.distance_to(city_j))
    pos_min_distance = distances.index(min(distances))
    next_closest_city = neighbors[pos_min_distance]
    ant.visit(next_closest_city)
print(ant.tour)
print(ant.tour_weight)
```

    [1, 2, 4, 7, 11, 16, 22, 29, 28, 27, 23, 26, 25, 24, 20, 21, 19, 18, 17, 14, 15, 13, 12, 8, 9, 6, 5, 10, 3]
    56645
    time: 4.18 ms


## ANT SYSTEM


```python
def ant_system():
    # INIT MATRIX for each CITY IJ with TAU INITIAL (t_0)
    _pheromones_row = [TAU_INITIAL for i in range(N)]
    pheromones_matrix = [_pheromones_row for j in range(N)]

    history_list = []

    for step in range(STEPS):
        ants_list = []
        for ant_i in range(M_ANTS):
            # pick a starting point
            first_random_city = randrange(N)+1
            ant = Ant(first_random_city)
            ants_list.append(ant)
            while not ant.finished_tour():
                # calculate probability P_j for all unvisited neightbors J
                    # ANT SYSTEM (AS): Probability of each edge in the neighborhood
                    # p_ij_k = (t_ij^a * (1/d_ij)^b ) / SUM(all feasible g edges) # It's like edge normalized
                neighbors, probabilities = ant.normalized_probabilities(pheromones_matrix) # sum(probabilities) == 1
                # pick the next node using the probabilities
                next_city = ant.pick_next_city(neighbors, probabilities)
                ant.visit(next_city)
            ant.visit(first_random_city) # Close cycle??
        history_list.append(ants_list.copy()) # save results
        # update pheromone values based upon the quality of each solution
            # ANT SYSTEM (AS): All ants contribute updating the pheromone as follows
            # TAU_I_J = (1-RO)*TAU_I_J + SUM(Q/(Lk or 0)) # Attention! In TSP Lk will be always the same == N Total cities
                                               # Probably in TSP the length means the distance
        pheromones_to_add = [[0 for i in range(N)] for j in range(N)]
        for ant in ants_list:
            tau_delta = Q/ant.tour_weight
            for tour_i in range(1, len(ant.tour)):
                i = ant.tour[tour_i-1]-1 # city
                j = ant.tour[tour_i]-1 # next city
                pheromones_to_add[i][j] += tau_delta
        # update fermonones
        df = pd.DataFrame(pheromones_matrix)*(1-RO)+pd.DataFrame(pheromones_to_add)
        pheromones_matrix = df.values
        # PLOT every 10th of steps
        if step % int(STEPS/100) == 0:
            plot_pheromones(df,step=step+1, title="Step %s from %s."%(step+1,STEPS))
    # Plot last result
    plot_pheromones(df,step=step+1, title="Step %s from %s."%(step+1,STEPS))
    return history_list, ants_list
```

    time: 3.56 ms



```python
M_ANTS = int(N) # Number of ants ~ to number of nodes (N)
ALPHA = 1 # History coefficietn ~ 1
BETA = 3 # 0,1,2,3,4,5,6 # Heuristic Coefficient [2,5]
RO = 0.2# Evaporation rate # It's like cooling. A high value is similar to very decrease the temparature drastically and get stucked in a local optimum
Q = 1*30000 # Pheromone change factor
TAU_INITIAL = 1/70000 # Initial pheromone ~ 1/RO*C^nn ; C^nn is the length of the tour generated by the nearest neighbor heuristic
STEPS = 1000

history_list, ants_list = ant_system()
```

    Step 1 from 1000.



![png](output_20_1.png)


    Step 11 from 1000.



![png](output_20_3.png)


    Step 21 from 1000.



![png](output_20_5.png)


    Step 31 from 1000.



![png](output_20_7.png)


    Step 41 from 1000.



![png](output_20_9.png)


    Step 51 from 1000.



![png](output_20_11.png)


    Step 61 from 1000.



![png](output_20_13.png)


    Step 71 from 1000.



![png](output_20_15.png)


    Step 81 from 1000.



![png](output_20_17.png)


    Step 91 from 1000.



![png](output_20_19.png)


    Step 101 from 1000.



![png](output_20_21.png)


    Step 111 from 1000.



![png](output_20_23.png)


    Step 121 from 1000.



![png](output_20_25.png)


    Step 131 from 1000.



![png](output_20_27.png)


    Step 141 from 1000.



![png](output_20_29.png)


    Step 151 from 1000.



![png](output_20_31.png)


    Step 161 from 1000.



![png](output_20_33.png)


    Step 171 from 1000.



![png](output_20_35.png)


    Step 181 from 1000.



![png](output_20_37.png)


    Step 191 from 1000.



![png](output_20_39.png)


    Step 201 from 1000.



![png](output_20_41.png)


    Step 211 from 1000.



![png](output_20_43.png)


    Step 221 from 1000.



![png](output_20_45.png)


    Step 231 from 1000.



![png](output_20_47.png)


    Step 241 from 1000.



![png](output_20_49.png)


    Step 251 from 1000.



![png](output_20_51.png)


    Step 261 from 1000.



![png](output_20_53.png)


    Step 271 from 1000.



![png](output_20_55.png)


    Step 281 from 1000.



![png](output_20_57.png)


    Step 291 from 1000.



![png](output_20_59.png)


    Step 301 from 1000.



![png](output_20_61.png)


    Step 311 from 1000.



![png](output_20_63.png)


    Step 321 from 1000.



![png](output_20_65.png)


    Step 331 from 1000.



![png](output_20_67.png)


    Step 341 from 1000.



![png](output_20_69.png)


    Step 351 from 1000.



![png](output_20_71.png)


    Step 361 from 1000.



![png](output_20_73.png)


    Step 371 from 1000.



![png](output_20_75.png)


    Step 381 from 1000.



![png](output_20_77.png)


    Step 391 from 1000.



![png](output_20_79.png)


    Step 401 from 1000.



![png](output_20_81.png)


    Step 411 from 1000.



![png](output_20_83.png)


    Step 421 from 1000.



![png](output_20_85.png)


    Step 431 from 1000.



![png](output_20_87.png)


    Step 441 from 1000.



![png](output_20_89.png)


    Step 451 from 1000.



![png](output_20_91.png)


    Step 461 from 1000.



![png](output_20_93.png)


    Step 471 from 1000.



![png](output_20_95.png)


    Step 481 from 1000.



![png](output_20_97.png)


    Step 491 from 1000.



![png](output_20_99.png)


    Step 501 from 1000.



![png](output_20_101.png)


    Step 511 from 1000.



![png](output_20_103.png)


    Step 521 from 1000.



![png](output_20_105.png)


    Step 531 from 1000.



![png](output_20_107.png)


    Step 541 from 1000.



![png](output_20_109.png)


    Step 551 from 1000.



![png](output_20_111.png)


    Step 561 from 1000.



![png](output_20_113.png)


    Step 571 from 1000.



![png](output_20_115.png)


    Step 581 from 1000.



![png](output_20_117.png)


    Step 591 from 1000.



![png](output_20_119.png)


    Step 601 from 1000.



![png](output_20_121.png)


    Step 611 from 1000.



![png](output_20_123.png)


    Step 621 from 1000.



![png](output_20_125.png)


    Step 631 from 1000.



![png](output_20_127.png)


    Step 641 from 1000.



![png](output_20_129.png)


    Step 651 from 1000.



![png](output_20_131.png)


    Step 661 from 1000.



![png](output_20_133.png)


    Step 671 from 1000.



![png](output_20_135.png)


    Step 681 from 1000.



![png](output_20_137.png)


    Step 691 from 1000.



![png](output_20_139.png)


    Step 701 from 1000.



![png](output_20_141.png)


    Step 711 from 1000.



![png](output_20_143.png)


    Step 721 from 1000.



![png](output_20_145.png)


    Step 731 from 1000.



![png](output_20_147.png)


    Step 741 from 1000.



![png](output_20_149.png)


    Step 751 from 1000.



![png](output_20_151.png)


    Step 761 from 1000.



![png](output_20_153.png)


    Step 771 from 1000.



![png](output_20_155.png)


    Step 781 from 1000.



![png](output_20_157.png)


    Step 791 from 1000.



![png](output_20_159.png)


    Step 801 from 1000.



![png](output_20_161.png)


    Step 811 from 1000.



![png](output_20_163.png)


    Step 821 from 1000.



![png](output_20_165.png)


    Step 831 from 1000.



![png](output_20_167.png)


    Step 841 from 1000.



![png](output_20_169.png)


    Step 851 from 1000.



![png](output_20_171.png)


    Step 861 from 1000.



![png](output_20_173.png)


    Step 871 from 1000.



![png](output_20_175.png)


    Step 881 from 1000.



![png](output_20_177.png)


    Step 891 from 1000.



![png](output_20_179.png)


    Step 901 from 1000.



![png](output_20_181.png)


    Step 911 from 1000.



![png](output_20_183.png)


    Step 921 from 1000.



![png](output_20_185.png)


    Step 931 from 1000.



![png](output_20_187.png)


    Step 941 from 1000.



![png](output_20_189.png)


    Step 951 from 1000.



![png](output_20_191.png)


    Step 961 from 1000.



![png](output_20_193.png)


    Step 971 from 1000.



![png](output_20_195.png)


    Step 981 from 1000.



![png](output_20_197.png)


    Step 991 from 1000.



![png](output_20_199.png)


    Step 1000 from 1000.



![png](output_20_201.png)


    time: 1min 44s



```python
tours_weight_list = [a.tour_weight for a in ants_list]
print(tours_weight_list)
```

    [41351, 31372, 34077, 35440, 32719, 31917, 34205, 33851, 37476, 31039, 33526, 37369, 36932, 34237, 34377, 33935, 36117, 31336, 40418, 31174, 38788, 32738, 33621, 32822, 32822, 34336, 33455, 33517, 37731]
    time: 5.33 ms



```python
#pos_min = tours_weight_list.index(min(tours_weight_list))
all_ants_list = [ant for ants_step_list in history_list for ant in ants_step_list]
all_tours_weight_list = [a.tour_weight for a in all_ants_list]
pos_min = all_tours_weight_list.index(min(all_tours_weight_list))
print("Min weigth: %s"%all_tours_weight_list[pos_min])
best_tour = all_ants_list[pos_min].tour
print("Best Tour: %s"%best_tour)
```

    Min weigth: 27799
    Best Tour: [15, 19, 18, 17, 21, 22, 23, 29, 28, 26, 20, 25, 27, 24, 16, 14, 13, 9, 7, 3, 4, 8, 5, 6, 2, 1, 10, 11, 12, 15]
    time: 3.2 s



```python
pd.DataFrame(all_tours_weight_list).plot(figsize=(15,10))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fc323743f10>




![png](output_23_1.png)


    time: 623 ms



```python
pd.DataFrame([min([a.tour_weight for a in ants_step_list]) for ants_step_list in history_list]).plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fc323254d90>




![png](output_24_1.png)


    time: 3.52 s



```python
pd.DataFrame([max([a.tour_weight for a in ants_step_list]) for ants_step_list in history_list]).plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fc30a4b3a50>




![png](output_25_1.png)


    time: 3.35 s



```python
pd.DataFrame([np.mean([a.tour_weight for a in ants_step_list]) for ants_step_list in history_list]).plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fc306b2e350>




![png](output_26_1.png)


    time: 3.27 s



```python
map_df_lat = pd.DataFrame([PROBLEM.node_coords[i][0] for i in best_tour], columns=['lat'])
map_df_long = pd.DataFrame([PROBLEM.node_coords[i][1] for i in best_tour], columns=['long'])*-1
print(len(map_df_lat))
plt.figure(figsize=(15,10))
plt.plot(map_df_long,
              map_df_lat,
              c='DarkBlue',
              #style=['o', 'rx'],
              #s=2,
              #figsize=(15,8),
              marker="o",
              markerfacecolor="r")
```

    30





    [<matplotlib.lines.Line2D at 0x7fc30a31d710>]




![png](output_27_2.png)


    time: 189 ms



```python

```
